| `Version` | `Update Notes`                                                                                      |
|-----------|-----------------------------------------------------------------------------------------------------|
| 1.0.1     | - Simplify the code since the base game will already log the character isn't supported in the font. |
| 1.0.0     | - Initial Release                                                                                   |